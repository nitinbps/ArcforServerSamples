﻿
function Install-ESUIntermediateCert 
{
    [CmdletBinding()]
    param ()

    # run this script on elevated powershell.exe 
    $cert = "$psscriptroot\Microsoft Azure TLS Issuing CA 01 - xsign.crt"
    if( -not (Test-Path $cert)) {
        throw "Microsoft Azure TLS Issuing CA 01 - xsign.crt not found in $psscriptroot"
     }

    certutil -addstore CA $cert
 
    Write-Verbose "Please reboot the machine if machine needs a reboot before installing the updates."
}

Install-ESUIntermediateCert  -verBose
##Reboot the machine if machine needs a reboot before installing the updates.
